
# Endian String Convert

Change string to little endian & big endian



## Badges


[![MIT License](https://img.shields.io/badge/License-MIT-green.svg)](https://choosealicense.com/licenses/mit/)

[![PyPI](https://img.shields.io/pypi/v/package.svg?style=flat-square)](https://pypi.python.org/pypi/package)

[![PyPI](https://img.shields.io/pypi/l/package.svg?style=flat-square)](https://pypi.python.org/pypi/package)

## Installation

Install python libary using pip3

```bash
  pip3 install module_name
```
OR

```bash
python3 -m pip install module_name
```
## Authors

- [@kunaldesign](https://github.com/kunaldesign) 🥇
- [@s-rebel](https://github.com/s-rebel) 🥈

## License

[MIT](https://choosealicense.com/licenses/mit/)


## Support

For support, email kunalhedaoo25@gmail.com, aglaweshubham17@gmail.com


## Features

- Convert little endian to big endian
- Convert big endian to little endian


## Contributing

Contributions are always welcome!

See `contributing.md` for ways to get started.

Please adhere to this project's `code of conduct`.

